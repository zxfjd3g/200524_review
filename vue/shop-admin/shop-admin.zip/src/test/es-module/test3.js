// import {default as xxx2} from './test1'
// 导入并导出默认导出的模块
export {default as xxx2} from './test1'

// import {yyy, zzz} from './test1'
// 导入并导出分别导出的模块
export {yyy, zzz} from './test1'

// import {a, b, c, d} from './test1'
// 导入并导出统一导出的模块
export {a, b, c, d} from './test1'
