import * as test3 from './test3'
// console.log(test3)
