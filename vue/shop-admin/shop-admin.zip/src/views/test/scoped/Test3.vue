<template>
  <div class="test3">
    <h2 class="t2">t2--Test3</h2>
    <h2 class="t22">t22--Test3</h2>
  </div>
</template>

<script>
export default {
  name: 'Test3',
}
</script>
