<template>
  <div class="test4">
    Test4
  </div>
</template>

<script>
export default {
  name: 'Test4',
}
</script>

<style>

</style>
